## NLP-Tennis-Bot
A Conversational chatbot built with NLTK and Tensorflow on tennis corpus

This project utilizes cutting-edge tools, frameworks and libraries to such as Tensorflow, Streamlit, Web scrapping tools to build an 
intelligent conversational chatbot center around Tennis.

## Check App 
![BoTennis ](https://share.streamlit.io/opeyemibami/nlp-tennis-bot/master/app.py)

## Read a well detailed project article published with [FritzAi/Heartbeat](https://heartbeat.fritz.ai/building-a-conversational-chatbot-with-nltk-and-tensorflow-part-1-f452ce1756e5)
